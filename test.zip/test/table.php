<?php
$token = bin2hex(random_bytes(25));
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>example-table-dataly</title>
  <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="mycss/table-edit.css">
  <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<link rel="icon" href="img/logodatary.png" type="image/jpeg" sizes="16x16">

<script>
    window.addEventListener('pageshow', function(event) {
    // เช็คว่าเคยรีเฟรชแล้วรอบนึงไหม
    if (!sessionStorage.getItem('reloaded')) {
        sessionStorage.setItem('reloaded', 'true');
        window.location.reload();
    } else {
        // เคยรีเฟรชแล้ว ล้าง sessionStorage เพื่อให้รอบถัดไปโหลดใหม่ปกติ
        sessionStorage.removeItem('reloaded');
    }
});
</script>
</head>
<body>
  <a class="btn btn-lg btn-primary" href="index.php?token=<?= $token ?>" role="button"> EXIT </a>
  <br>
  <table border="1">
    <thead>
      <tr class="1">
        <th>ลำดับ</th>
        <th>วันที่</th>
        <th>รายละเอียดของงาน</th>
        <th>เวลาเริ่ม</th>
        <th>เวลาเลิก</th>
      </tr>
    </thead>
    <tbody>
      <tr class="2">
        <td>001</td>
        <td>01</td>
        <td>เขียนโค้ด</td>
        <td>09:00</td>
        <td>17:00</td>
      </tr>
      <tr class="3">
        <td>002</td>
        <td>02</td>
        <td>แก้ไขbatabase</td>
        <td>09:00</td>
        <td>17:00</td>
      </tr>
    </tbody>

    <tbody>
      <tr class="3">
        <td>003</td>
        <td>03</td>
        <td>จัดการะบบ</td>
        <td>09:00</td>
        <td>17.00</td>
      </tr>
    </tbody>
    <tbody>
      <tr class="3">
        <td>004</td>
        <td>04</td>
        <td>เปลี่ยนรหัสapi</td>
        <td>09:00</td>
        <td>17.00</td>
      </tr>
    </tbody>
    <tbody>
      <tr class="3">
        <td>005</td>
        <td>05</td>
        <td>จัดการระบบหลังบ้าน</td>
        <td>09:00</td>
        <td>17.00</td>
      </tr>
  </table>
</body>

</html>