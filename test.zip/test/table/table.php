<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once('../API/connect.php');

if (empty($_SESSION['id'])) {
    header("Location: ../nologin.php");
    exit;
}
$token = bin2hex(random_bytes(25));
$user_id = $_SESSION['id'];

$stmt = $conn->prepare("SELECT id, work_date, detail, time_start, time_end FROM work_table WHERE user_id = ? ORDER BY id DESC LIMIT 10");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$workData = [];
while ($row = $result->fetch_assoc()) {
    $workData[] = $row;
}
$stmt->close();

for ($i = count($workData); $i < 10; $i++) {
    $workData[] = ['id' => '', 'work_date' => '', 'detail' => '', 'time_start' => '', 'time_end' => ''];
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8" />
  <title>จัดการข้อมูลงาน</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css" />
  <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <link rel="icon" href="img/logodatary.png" type="image/jpeg" sizes="16x16">
<script>
    window.addEventListener('pageshow', function(event) {
    // เช็คว่าเคยรีเฟรชแล้วรอบนึงไหม
    if (!sessionStorage.getItem('reloaded')) {
        sessionStorage.setItem('reloaded', 'true');
        window.location.reload();
    } else {
        // เคยรีเฟรชแล้ว ล้าง sessionStorage เพื่อให้รอบถัดไปโหลดใหม่ปกติ
        sessionStorage.removeItem('reloaded');
    }
});
</script>
</head>
<body>
  <div class="container mt-4">
    <a class="btn btn-primary mb-3" href="../index.php?token=<?= $token ?>">กลับหน้าแรก</a>

    <form method="post" action="../API/save_work.php">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>id</th>
            <th>วันที่</th>
            <th>รายละเอียด</th>
            <th>เวลาเริ่ม</th>
            <th>เวลาเลิก</th>
            <th>การจัดการ</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($workData as $row): ?>
            <tr id="row-<?= htmlspecialchars($row['id']) ?>">
              <td>
                <input type="text" class="form-control" value="<?= htmlspecialchars($row['id']) ?>" disabled>
                <input type="hidden" name="id[]" value="<?= htmlspecialchars($row['id']) ?>">
              </td>
              <td>
                <input type="date" name="work_date[]" id="date-<?= htmlspecialchars($row['id']) ?>" class="form-control" value="<?= htmlspecialchars($row['work_date']) ?>">
              </td>
              <td>
                <input type="text" name="detail[]" id="detail-<?= htmlspecialchars($row['id']) ?>" class="form-control" value="<?= htmlspecialchars($row['detail']) ?>">
              </td>
              <td>
                <input type="time" name="time_start[]" id="start-<?= htmlspecialchars($row['id']) ?>" class="form-control" value="<?= htmlspecialchars($row['time_start']) ?>">
              </td>
              <td>
                <input type="time" name="time_end[]" id="end-<?= htmlspecialchars($row['id']) ?>" class="form-control" value="<?= htmlspecialchars($row['time_end']) ?>">
              </td>
              <td>
                <?php if (!empty($row['id']) && is_numeric($row['id'])): ?>
                  <div class="d-flex gap-2">
                    <button type="button" class="btn btn-success btn-sm" onclick="editWork(<?= $row['id'] ?>)">แก้ไข</button>
                    <button type="button" class="btn btn-danger btn-sm" onclick="deleteWork(<?= $row['id'] ?>)">ลบ</button>
                  </div>
                <?php else: ?>
                  <div class="d-flex gap-2">
                    <button class="btn btn-secondary btn-sm" disabled>แก้ไข</button>
                    <button class="btn btn-secondary btn-sm" disabled>ลบ</button>
                  </div>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>

      <button type="submit" class="btn btn-primary">💾 บันทึกทั้งหมด</button>
    </form>
  </div>

  <script>
    function deleteWork(id) {
      if (confirm('คุณต้องการลบข้อมูลนี้หรือไม่?')) {
        const formData = new FormData();
        formData.append('id', id);

        axios.post('../API/delete.php', formData)
          .then(response => {
            if (response.data.success) {
              document.getElementById('row-' + id).remove();
              alert('ลบสำเร็จ');
            } else {
              alert('เกิดข้อผิดพลาด: ' + response.data.message);
            }
          })
          .catch(error => {
            console.error(error);
            alert('ลบไม่สำเร็จ');
          });
      }
    }

    function editWork(id) {
      const date = document.getElementById('date-' + id)?.value || '';
      const detail = document.getElementById('detail-' + id)?.value || '';
      const start = document.getElementById('start-' + id)?.value || '';
      const end = document.getElementById('end-' + id)?.value || '';

      console.log({ id, date, detail, start, end }); // Debug

      if (!id || !date || !detail || !start || !end) {
        alert('กรุณากรอกข้อมูลให้ครบ');
        return;
      }

      const data = new FormData();
      data.append('id', id);
      data.append('work_date', date);
      data.append('detail', detail);
      data.append('time_start', start);
      data.append('time_end', end);

      axios.post('../API/edit.php', data)
        .then(response => {
          if (response.data.success) {
            alert('แก้ไขสำเร็จ');
          } else {
            alert('เกิดข้อผิดพลาด: ' + response.data.message);
          }
        })
        .catch(error => {
          console.error(error);
          alert('แก้ไขไม่สำเร็จ');
        });
    }
  </script>
</body>
</html>
